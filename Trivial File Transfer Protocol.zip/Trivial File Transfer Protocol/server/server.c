#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <arpa/inet.h>
#include <fcntl.h>
#define  port 5000
int ack,b,normal,octal;
int main(){
    int sock_fd,file_fd;
    int a;
    struct sockaddr_in serv_addr, cli_addr;
    socklen_t len;
    char buffer[1024];
    char buff[513];
    sock_fd = socket(AF_INET, SOCK_DGRAM, 0);
    if(sock_fd == -1)
    {
        perror("socket");
        exit(1);
    }
    serv_addr.sin_family = AF_INET; 
    serv_addr.sin_port = htons(port); 
    serv_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    bind(sock_fd,(struct sockaddr *)&serv_addr,sizeof(serv_addr));
    len = sizeof(cli_addr);
    while(1){
        recvfrom(sock_fd,&b,sizeof(b),0,(struct sockaddr *)&cli_addr,&len);
        if(b==1){
            break;
        }
        recvfrom(sock_fd,&a,sizeof(a),0,(struct sockaddr *)&cli_addr,&len);
        if(a==1){
            recvfrom(sock_fd,buffer,sizeof(buffer),0,(struct sockaddr *)&cli_addr,&len);
            printf("file name is %s\n",buffer);
            file_fd = open(buffer, O_TRUNC | O_WRONLY);
            if(file_fd == -1){
                file_fd = open(buffer , O_CREAT | O_TRUNC | O_WRONLY , 0644);
                if(file_fd == -1){
                    perror("open");
                    ack=0;
                    sendto(sock_fd,&ack,sizeof(ack),0,(struct sockaddr *)&cli_addr, sizeof(cli_addr));
                    continue;
                }
                ack=1;
                sendto(sock_fd,&ack,sizeof(ack),0,(struct sockaddr *)&cli_addr, sizeof(cli_addr));
                while(1){
                    int n = recvfrom(sock_fd,buff,sizeof(buff),0,(struct sockaddr *)&cli_addr,&len);
                    if(strcmp(buff,"EOF")==0)
                        break;
                    int ret = write(file_fd,buff,n);
                    if(ret != n){
                        ack  =0;
                    }
                    else{
                        ack =1;
                    }
                    sendto(sock_fd,&ack,sizeof(ack),0,(struct sockaddr *)&cli_addr, len);
                }
            }
            else{
                ack=1;
                sendto(sock_fd,&ack,sizeof(ack),0,(struct sockaddr *)&cli_addr, len);
                while(1){
                    //printf("HI\n");
                    int n = recvfrom(sock_fd,buff,sizeof(buff),0,(struct sockaddr *)&cli_addr,&len);
                    if(strcmp(buff,"EOF")==0)
                        break;
                    int ret = write(file_fd,buff,n);
                    if(ret != n){
                        ack  =0;
                    }
                    else{
                        ack =1;
                    }
                    sendto(sock_fd,&ack,sizeof(ack),0,(struct sockaddr *)&cli_addr, len);
                
                }
            }
            close(file_fd);
        }
        else if(a==2){
            recvfrom(sock_fd,&normal,sizeof(normal),0,(struct sockaddr *)&cli_addr,&len);
            recvfrom(sock_fd,&octal,sizeof(octal),0,(struct sockaddr *)&cli_addr,&len);
            recvfrom(sock_fd,&net_ascci,sizeof(net_ascci),0,(struct sockaddr *)&cli_addr,&len);
            recvfrom(sock_fd,buffer,sizeof(buffer),0,(struct sockaddr *)&cli_addr,&len);
            printf("file name is %s\n",buffer);
            file_fd = open(buffer, O_RDONLY);
            if(file_fd == -1){
                perror("open");
                ack=0;
                sendto(sock_fd,&ack,sizeof(ack),0,(struct sockaddr *)&cli_addr, sizeof(cli_addr));
                continue;
            }
            ack=1;
            sendto(sock_fd,&ack,sizeof(ack),0,(struct sockaddr *)&cli_addr, sizeof(cli_addr));
            recvfrom(sock_fd,&ack,sizeof(ack),0,(struct sockaddr *)&cli_addr,&len);
            if(ack==1){
                while(1){
                    int bytes;
                    if(normal==1){
                        bytes = read(file_fd,buff,512);
                    }
                    else if(octal==1){
                        bytes = read(file_fd,buff,1);
                    }
                    else if(net_ascci==1){
                        bytes = read(file_fd,buff,1);
                        if(strcmp(buff,"\r")==0){
                            continue;
                        }
                    }
                    if(bytes==-1){
                        perror("read");
                        break;
                    }
                    if(bytes == 0)
                    {
                        strcpy(buff,"EOF");
                        sendto(sock_fd, buff, strlen(buff)+1 , 0, (struct sockaddr *)&cli_addr, sizeof(cli_addr));
                        break;
                    }
                    while(1)
                    {
                        sendto(sock_fd, buff, bytes, 0,(struct sockaddr *)&cli_addr, sizeof(cli_addr));
                        if(recvfrom(sock_fd, &ack, sizeof(ack), 0,(struct sockaddr *)&cli_addr, &len) == -1)
                        {
                            perror("recvfrom");
                            close(file_fd);
                            break;
                        }
                        if(ack == 1)
                            break;
                        printf("ACK failed... Resending packet\n");
                    }

                }
            }
            else{
                printf("File is not present\n");
            }
            close(file_fd);
        }
    }
}