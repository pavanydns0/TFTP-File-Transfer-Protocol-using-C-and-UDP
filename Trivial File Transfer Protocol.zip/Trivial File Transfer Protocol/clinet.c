#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <arpa/inet.h>
#include <fcntl.h>
int sock_fd,file_fd;
struct sockaddr_in serv_addr;
int connect_id =0;
int  validate(char *str){
    int dot_count = 0;
    int digit_count = 0;
    int num = 0;
    for(int i=0;str[i] != 0;i++){
        if(str[i] >= '0' && str[i] <= '9'){
            num = num * 10 + (str[i] -'0');
            digit_count++;
            if(num>255){
                return 0;
            } 
        }
        else if(str[i] == '.'){
            if(digit_count==0){
                return 0;
            }
            dot_count++;
            if(dot_count > 3){
                return 0;
            }
            num=0;
            digit_count=0;
        }
        else{
            return 0;
        }
    }
    if(dot_count != 3){
        return 0;
    }
    if(digit_count == 0){
        return 0;
    }
    return 1;
}
void client_connect(){
    char str[100];
    int port;
    printf("Enter server port : ");
    scanf("%d",&port);
    printf("Enter the ip addrress\n");
    scanf(" %[^\n]",str);
    int ret = validate(str);
    if(ret==0){
        printf("Invalid IP address\n");
        return;
    }
    else{
        sock_fd = socket(AF_INET, SOCK_DGRAM, 0);
        if(sock_fd == -1)
        {
            perror("socket");
            return;
        }
        connect_id = 1;
        printf("Socket created successfully.\n");
        serv_addr.sin_family = AF_INET; 
        serv_addr.sin_port = htons(port); 
        serv_addr.sin_addr.s_addr = inet_addr(str);
    }
    return;

}
void put_file(){
    if(connect_id == 0)
    {
        printf("Please connect to the server first.\n");
        return;
    }
    char str[100];
    printf("Enter the file name \n");
    scanf(" %[^\n]",str);
    file_fd = open(str,O_RDONLY);
    if(file_fd == -1)
    {
        perror("open");
        return;
    }
    sendto(sock_fd,str,strlen(str) + 1,0,(struct sockaddr *)&serv_addr, sizeof(serv_addr));
    int len= sizeof(serv_addr);
    recvfrom(sock_fd,buff,sizeof(buff),0,(struct sockaddr *)&serv_addr,&len);
    printf("hi\n");
    printf("%s\n",buff);
    if(strcmp(buff,"ACK")==0){
        //data_transfer
        printf("HI\n");
    }
    else{
        printf("File is not present\n");
    }
    close(file_fd);


}
void get_file(){

}
void set_mode(){

}
int main(){
    int choice;
    char str[100],buf[100];
    while (1)
    {
        printf("\n========== TFTP CLIENT ==========\n");
        printf("1. Connect\n");
        printf("2. Put\n");
        printf("3. Get\n");
        printf("4. Mode\n");
        printf("5. Exit\n");
        printf("Enter your choice : ");
        scanf("%d", &choice);

        switch (choice)
        {
            case 1:
            {
                if(connect_id == 0)
                {
                    client_connect();
                }
                else
                {
                    printf("Already connected.\n");
                }
                break;
            }

            case 2:
                put_file();
                break;

            case 3:
                get_file();
                break;

            case 4:
                set_mode();
                break;

            case 5:
                printf("Exiting...\n");
                exit(0);

            default:
                printf("Invalid choice\n");
                break;
        }
    }
    return 0;
}